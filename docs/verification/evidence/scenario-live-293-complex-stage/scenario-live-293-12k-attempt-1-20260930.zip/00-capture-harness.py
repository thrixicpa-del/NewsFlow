"""Opt-in, disposable capture for one normal NewsFlow Scenario pipeline run.

This is deliberately outside the repository.  It never writes settings or
credentials, captures no HTTP headers, and is meant only for the acceptance
evidence requested for PR #293.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch


ROOT = Path.cwd().resolve()
TITLE_A = (
    "МИР ОПЯТЬ ОТКЛАДЫВАЕТСЯ? — РОССИЯ УСИЛИЛА УДАРЫ ПО УКРАИНЕ — "
    "КИЕВ СНОВА ОКАЗАЛСЯ ПОД МАССИРОВАННОЙ АТАКОЙ"
)
SECRET_PATTERNS = (
    re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"\bAIza[A-Za-z0-9_-]{30,}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
)


def sha(value: str | bytes) -> str:
    return hashlib.sha256(value.encode("utf-8") if isinstance(value, str) else value).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def production_hashes(local_appdata: Path) -> dict[str, str | None]:
    root = local_appdata / "NewsFlow"
    return {
        name: sha((root / name).read_bytes()) if (root / name).is_file() else None
        for name in ("settings.json", "covers-library.json", "footage-index-status.json", "session.json")
    }


def safe_response_meta(response: object) -> dict:
    if not isinstance(response, dict):
        return {"status": "UNKNOWN", "response_type": type(response).__name__}
    return {
        "id": response.get("id", "UNKNOWN"),
        "model": response.get("model", "UNKNOWN"),
        "status": response.get("status", "UNKNOWN"),
        "usage": response.get("usage", "UNKNOWN"),
        "incomplete_details": response.get("incomplete_details", "UNKNOWN"),
        "output_text_chars": len(str(response.get("output_text", ""))),
    }


def redact(value: object) -> object:
    if isinstance(value, dict):
        return {
            str(key): ("[REDACTED]" if str(key).casefold() in {
                "authorization", "api_key", "apikey", "secret", "password", "cookie"
            } else redact(child))
            for key, child in value.items()
        }
    if isinstance(value, list):
        return [redact(child) for child in value]
    return value


class RecordingPool:
    """Normal OpenAI pool with a logical-call ledger; no retry policy change."""

    def __init__(self, sessions, openai_keys, chat_url, model):
        from scriptor.openai_client import HybridTextPool
        self.inner = HybridTextPool(sessions, openai_keys, chat_url, model)
        self.concurrency = self.inner.concurrency
        self.calls: list[dict] = []

    @staticmethod
    def phase(prompt: str, method: str) -> str:
        if "structural repairer" in prompt:
            return "STRUCTURAL_REPAIR"
        if prompt.startswith("FRESH STORY PLANNER RETRY"):
            return "FRESH_PLANNER"
        if "NewsFlow Story Planner" in prompt:
            return "PLANNER"
        match = re.search(r"CURRENT PART: (P\d+)", prompt)
        return f"WRITER_{match.group(1)}" if match else f"WRITER_UNKNOWN:{method}"

    async def _call(self, method: str, prompt: str, *args, **kwargs):
        entry = {
            "call_id": len(self.calls) + 1,
            "logical_method": method,
            "phase": self.phase(prompt, method),
            "prompt_sha256": sha(prompt),
            "prompt_chars": len(prompt),
            "max_output_tokens": kwargs.get("max_output_tokens", "UNKNOWN"),
            "capture": "CAPTURED",
        }
        self.calls.append(entry)
        try:
            output = await getattr(self.inner, method)(prompt, *args, **kwargs)
            entry.update({"response_chars": len(output), "response_sha256": sha(output), "result": "OK"})
            return output
        except Exception as error:  # evidence only; production runner owns its error semantics
            entry.update({"result": "ERROR", "error_type": type(error).__name__, "error_chars": len(str(error))})
            raise

    async def generate(self, prompt: str, *args, **kwargs):
        return await self._call("generate", prompt, *args, **kwargs)

    async def generate_fresh(self, prompt: str, *args, **kwargs):
        return await self._call("generate_fresh", prompt, *args, **kwargs)

    async def generate_openai(self, prompt: str, *args, **kwargs):
        return await self._call("generate_openai", prompt, *args, **kwargs)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", default="")
    parser.add_argument("--title", default=TITLE_A)
    parser.add_argument("--target", type=int, default=12000)
    parser.add_argument("--minimum", type=int, default=11500)
    parser.add_argument("--maximum", type=int, default=12500)
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    if args.minimum > args.maximum:
        raise SystemExit("invalid requested contract")

    # Read settings once, before test-mode variables are set.  Secrets remain
    # only in this process memory and are never written to the evidence tree.
    sys.path.insert(0, str(ROOT))
    from scriptor.config import load_settings
    source_localappdata = Path(os.environ["LOCALAPPDATA"]).resolve()
    before = production_hashes(source_localappdata)
    source_settings = load_settings()
    active_keys = [item for item in source_settings.openai_api_keys if item.active and item.secret.strip()]
    if str(source_settings.scenario_provider).strip() != "openai" or not active_keys:
        raise SystemExit("normal OpenAI Scenario route is not configured")

    run_id = args.run_id or "scenario-live-293-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    evidence = Path(r"D:\NewsFlow-RC\test-profiles") / run_id
    if evidence.exists():
        raise SystemExit(f"evidence root already exists: {evidence}")
    evidence.mkdir(parents=True)
    test_root = evidence / "runtime-root"
    test_root.mkdir()
    os.environ.update({
        "NEWSFLOW_TEST_MODE": "1",
        "NEWSFLOW_TEST_ROOT": str(test_root),
        "NEWSFLOW_PRODUCTION_LOCALAPPDATA": str(source_localappdata),
        "LOCALAPPDATA": str(test_root),
        "TEMP": str(test_root),
        "TMP": str(test_root),
    })

    from scriptor import bridge
    from scriptor.core import PromptRange
    from scriptor.openai_client import OpenAITextClient
    from scriptor.session import load_session

    settings = copy.deepcopy(source_settings)
    # Preserve the actual chosen template and manual ranges.  This final
    # matching range overrides only the requested test length contract.
    settings.prompt_ranges = [*settings.prompt_ranges, PromptRange(1, 1, "", args.target, args.minimum, args.maximum)]
    item_id = "test-live-293-" + hashlib.sha256(args.title.encode("utf-8")).hexdigest()[:12]
    test_item = {
        "id": item_id, "title": args.title, "manual": True,
        "framing_type": "EDITORIAL", "topic": args.title,
        "core_event": "", "supporting_context": [], "script_requirements": [],
        "test_context_origin": "HEADLINE_ONLY_DRAMATIZED_TEST",
    }
    settings.idea_production_items = [test_item]
    settings.idea_scenario_context = {args.title: dict(test_item)}
    settings.idea_results = []
    settings.cover_queue = []

    requests: list[dict] = []
    responses: list[dict] = []
    original_request = OpenAITextClient._request

    def capturing_request(client, method, path, payload=None):
        attempt = len(requests) + 1
        safe_payload = redact(payload)
        write_json(evidence / f"request-{attempt:02d}-captured.json", safe_payload)
        record = {
            "transport_attempt": attempt, "method": method, "path": path,
            "payload_sha256": sha(json.dumps(safe_payload, ensure_ascii=False, sort_keys=True)),
            "payload_chars": len(json.dumps(safe_payload, ensure_ascii=False)), "capture": "CAPTURED",
            "headers": "REDACTED_NOT_CAPTURED",
        }
        requests.append(record)
        try:
            response = original_request(client, method, path, payload)
            meta = safe_response_meta(response)
            meta.update({"transport_attempt": attempt, "capture": "CAPTURED"})
            responses.append(meta)
            write_json(evidence / f"response-{attempt:02d}-transport-meta.json", meta)
            return response
        except Exception as error:
            responses.append({"transport_attempt": attempt, "capture": "CAPTURED", "error_type": type(error).__name__, "error_chars": len(str(error))})
            raise

    manifest = {
        "run_id": run_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_head": os.popen("git rev-parse HEAD").read().strip(),
        "git_status_short": os.popen("git status --short").read().strip(),
        "provider": settings.scenario_provider,
        "configured_model": settings.openai_model,
        "active_key_count": len(active_keys),
        "key_material": "NOT_CAPTURED_MEMORY_ONLY",
        "template_chars": len(settings.template),
        "template_sha256": sha(settings.template),
        "manual_prompt_ranges_count": len(source_settings.prompt_ranges),
        "test_contract_override": {"target_chars": args.target, "allowed_min": args.minimum, "allowed_max": args.maximum},
        "material_mode": "EDITORIAL/EVENT_FIRST + headline-only DRAMATIZED permitted",
        "production_context": "NONE: title is not factual evidence",
        "storage": {"mode": "NEWSFLOW_TEST_MODE", "test_root": str(test_root), "production_settings_written": False},
    }
    write_json(evidence / "00-run-manifest-safe.json", manifest)
    (evidence / "01-user-template.txt").write_text(settings.template, encoding="utf-8")
    write_json(evidence / "02-test-production-context.json", test_item)
    if args.preflight_only:
        write_json(evidence / "99-preflight.json", {"status": "PASS", "provider_calls": 0})
        return finish(evidence, before, source_localappdata, [], [], [], None)

    pool_box: dict[str, RecordingPool] = {}
    def pool_factory(*pool_args, **pool_kwargs):
        pool = RecordingPool(*pool_args, **pool_kwargs)
        pool_box["pool"] = pool
        return pool
    def no_persist_settings(_value):
        return None
    try:
        with patch.object(bridge, "load_settings", return_value=settings), \
             patch.object(bridge, "save_settings", side_effect=no_persist_settings), \
             patch.object(bridge, "HybridTextPool", side_effect=pool_factory), \
             patch.object(OpenAITextClient, "_request", new=capturing_request):
            bridge.add_scenarios({"titles": args.title})
            bridge.generate_scenarios({"provider": "openai", "indices": [0]})
    except Exception as error:
        write_json(evidence / "98-harness-exception.json", {"type": type(error).__name__, "message_chars": len(str(error))})
    titles, jobs = load_session()
    job = jobs[0] if jobs else None
    pool = pool_box.get("pool")
    calls = pool.calls if pool else []
    write_json(evidence / "10-logical-calls.json", calls)
    write_json(evidence / "11-transport-attempts.json", {"attempts": requests, "responses": responses, "sdk_retries": "UNKNOWN"})
    if job:
        write_json(evidence / "20-story-map-persisted.json", job.story_plan or {})
        write_json(evidence / "21-job-safe.json", {
            "state": job.state.value, "error": job.error, "actual_chars": job.actual_chars,
            "length_status": job.length_status, "story_planner_status": job.story_planner_status,
            "story_planner_failure": job.story_planner_failure,
            "accepted_story_parts": [{key: record.get(key) for key in ("part_id", "content_ids", "target_chars", "text")} for record in job.accepted_story_parts],
        })
        for record in job.accepted_story_parts:
            (evidence / f"part-{record['part_id']}.txt").write_text(str(record.get("text", "")), encoding="utf-8")
        (evidence / "scenario.txt").write_text(job.result, encoding="utf-8")
        write_json(evidence / "30-assembly.json", {
            "separator": "\\n\\n", "python_len_stripped": len(job.result.strip()), "scenario_sha256": sha(job.result),
            "parts": [{"part_id": record.get("part_id"), "target_chars": record.get("target_chars"), "chars": len(str(record.get("text", "")).strip()), "sha256": sha(str(record.get("text", "")))} for record in job.accepted_story_parts],
        })
    return finish(evidence, before, source_localappdata, requests, responses, calls, job)


def finish(evidence: Path, before: dict[str, str | None], source_localappdata: Path, requests: list, responses: list, calls: list, job: object) -> int:
    after = production_hashes(source_localappdata)
    guard = {"before": before, "after": after, "result": "PASS" if before == after else "FAIL"}
    write_json(evidence / "31-production-write-guard.json", guard)
    findings = []
    for candidate in evidence.rglob("*"):
        if candidate.is_file() and candidate.suffix.lower() in {".json", ".txt", ".py"}:
            data = candidate.read_text(encoding="utf-8", errors="replace")
            if any(pattern.search(data) for pattern in SECRET_PATTERNS):
                findings.append(candidate.name)
    write_json(evidence / "32-secret-export-scan.json", {"result": "PASS" if not findings else "FAIL", "matched_files": findings})
    if findings:
        raise RuntimeError("secret pattern found in evidence; ZIP refused")
    archive = evidence.with_suffix(".zip")
    summary = {
        "evidence_dir": str(evidence), "zip": str(archive),
        "logical_calls": len(calls),
        "transport_attempts_captured": len(requests), "production_write_guard": guard["result"],
        "job_state": getattr(getattr(job, "state", None), "value", "MISSING"),
    }
    write_json(evidence / "99-summary.json", summary)
    shutil.copy2(Path(__file__), evidence / "00-capture-harness.py")
    summary["zip"] = str(archive)
    write_json(evidence / "99-summary.json", summary)
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as bundle:
        for candidate in evidence.rglob("*"):
            if candidate.is_file():
                bundle.write(candidate, candidate.relative_to(evidence))
    print(json.dumps(summary, ensure_ascii=False))
    return 0 if guard["result"] == "PASS" else 91


if __name__ == "__main__":
    raise SystemExit(main())
