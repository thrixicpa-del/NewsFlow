# Disposable Scenario acceptance evidence

Run: `scenario-live-293-matrix-m2-20260930-200003`. This directory contains safe post-adapter payloads, visible model text, persisted Story Map/session projection, accepted parts, assembly facts and call ledgers. Credentials, headers, cookies, runtime-root and account settings are intentionally excluded.
